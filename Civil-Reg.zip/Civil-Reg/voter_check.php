<?php
session_start();
  if(!isset($_SESSION['user']))
  {
    header("Location: index.php");
  }
  $user = $_SESSION['user'];
  if(!isset($_SESSION['user_id']))
  {
    header("Location: index.php");
  }
  $user_id = $_SESSION['user_id'];

      include "config.php"; 


$servername="localhost";
$username="root";
$password="";
$dbname="civil";
$conn = new mysqli($servername, $username, $password,$dbname);
if ($conn->connect_error)
{
	die("Connection failed:".$conn->connect_error);
}
if(!isset($_SESSION['user_id']))
	{
		header("Location: index.php");
	}

	$user_id = $_SESSION['user_id'];


$sql = "INSERT INTO voter VALUES 
('','$_POST[firstName]', '$_POST[lastname]','$_POST[nsrelative]','$_POST[sonof]', '$_POST[age]',
'$_POST[bday]','$_POST[gender]','$_POST[building]','$_POST[street]','$_POST[town]','$_POST[area]',
'$_POST[city]','$_POST[state]','$_POST[pincode]','$_POST[locality]','$_POST[village]','$_POST[postoffice]',
'$_POST[city1]','$_POST[state2]','$_POST[pincode2]','$_POST[disability]','$_POST[email]','$_POST[phone]',
'$_POST[uploadimg]','$_POST[uploadadhar]','$user_id')";

if ($conn->query($sql) === TRUE) 
{
    echo "New record created successfully";
    header('Location:http://localhost/My_Projects1/home.php');
} 
else
 {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
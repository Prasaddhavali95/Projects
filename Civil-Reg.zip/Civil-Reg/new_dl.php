<?php

session_start();
  if(!isset($_SESSION['user']))
  {
    header("Location: index.php");
  }
  $user = $_SESSION['user'];
  if(!isset($_SESSION['user_id']))
  {
    header("Location: index.php");
  }
  $user_id = $_SESSION['user_id'];

      include "config.php";  // including configuration file
?>


<html>
<head>
<title>Civil Registry</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <script src="bootstrap/js/jquery.min.js"></script>
  <script src="bootstrap/js/bootstrap.min.js"></script>
</head>
<body id="top">

<div class="wrapper row0">
  <div id="topbar" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div class="fl_left">
      <ul class="nospace">
        <li><a href="#"><i class="fa fa-lg fa-home"></i></a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Contact</a></li>
        
      </ul>
    </div>
    <div class="fl_right">
      <ul class="nospace">
        <li><i class="fa fa-phone"></i> +91 8123400951</li>
        <li><i class="fa fa-envelope-o"></i> info@civil.com</li>
      </ul>
    </div>
    <!-- ################################################################################################ -->
  </div>
</div>

<div class="wrapper row1">
  <header id="header" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div id="logo" class="fl_left">
      <h1><a href="home.html">CIVIL REGISTRY</a></h1>
      <p></p>
    </div>
    <!-- ################################################################################################ -->
    <nav id="mainav" class="fl_right">
      <ul class="clear">
        <li class="active"><a href="home.html">Home</a></li>
        <li><a class="drop" href="#">Pages</a>
          <ul>
            <li><a href="#">Gallery</a></li>
          </ul>
        </li>
        <li><a class="drop" href="#">Services</a>
          <ul>
            <li><a href="new_pan_card.php">APPLY PAN CARD</a></li>
             <li><a href="new_voter_id.php">APPLY VOTER ID</a></li>
               <li><a href="new_dl.php">APPLY DRIVING LICENCE</a></li>
          </ul>
        </li>
        <li><a href="#">PORTFOLIO</a></li>
        
      </ul>
    </nav>
    <!-- ################################################################################################ -->
  </header>
</div>

<div class="wrapper bgded overlay" style="background-image:url('images/demo/backgrounds/Driving_License_issued_by_the_Transport_department_of_Karnataka_State.jpg');">
  <div id="pageintro" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <article>
      <div>
        <p class="heading">"Apply here for Your"</p>
        <h2 class="heading">New Driving License </h2>
        <p>.</p>
      </div>	
    </article>
    <!-- ################################################################################################ -->
  </div>
</div>
<br>

<div class="wrapper bgded overlay" style="background-image:url('images/demo/backgrounds/Batman_Amoled-wallpaper-11337056.jpg');">
<form action="dl_check.php" method="Post">
 <div id="pageintro" class="hoc clear"> 
       <fieldset><br>
           <legend align="center" class="text-white"><h3>Applying For New Driving License</h3></legend>
            <legend align="center" class="text-white"><h6>Form of Application for Licence to Drive a Motor Vehicle </h6></legend><br>


               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label for="firstName" class="text-white" align="center"><b>I apply for a License to enable me to drive vehicle(s) of the following description *</b> </label><br>
            <div class="form-group row">
                 
                 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <div class="col-md-5">                 
                        <select class="form-control"  name="names" required >
                          <option value="S">Select</option>
                      <option value="F"> Motor cycle without gear</option>
                      <option value="M">Motor cycle with gear</option>
                      <option value="H">Invalid carriage</option>
                      <option value="W">Light Motor vehicle</option>
                      <option value="O">Medium goods vehicle</option>
                      <option value="m">Medium passengers motor vehicle</option>
                      <option value="h">Heavy goods vehicle</option>
                      <option value="p">Heavy passenger motor vehicle</option>
                      <option value="r">Road roller Motor vehicle of the following description</option>
                      </select>
               </div>
            </div><br><br>

            <legend align="center" class="text-white"><h6>Particulars to be furnished by Applicant</h6></legend><br><br>

           <div class="form-group row">
         
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <div class="col-md-3">
                   <label for="firstName" class="text-white"><b>First Name *</b> </label>
                   <input type="text" class="form-control" name="firstName" 
                   id="firstName" placeholder="Please enter first name" pattern="[A-Za-z]+" title="only letters" required>
               </div>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <div class="col-md-3">
                   <label for="firstName" class="text-white"><b>Middle Name *</b> </label>
                   <input type="text" class="form-control" name="middlename" 
                   id="firstName" placeholder="Please enter first name" pattern="[A-Za-z]+" title="only letters" required>
               </div>
               <div class="col-md-3">
                   <label for="firstName" class="text-white"><b>SurName *</b> </label>
                   <input type="text" class="form-control" name="lastname" 
                   id="firstName" placeholder="Please enter last name" pattern="[A-Za-z]+" title="only letters" required>
               </div>
           </div><br><br>

         <label class="text-white">
              <b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Son/Wife/Daughter of *</b>
            </label><br>
           <div class="form-group row">
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <div class="col-md-3">
                   <label for="firstName" class="text-white"><b>First Name *</b> </label>
                   <input type="text" class="form-control" name="sfirstName" 
                   id="firstName" placeholder="Please enter first name" pattern="[A-Za-z]+" title="only letters" required>
               </div>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <div class="col-md-3">
                   <label for="firstName" class="text-white"><b>Middle Name *</b> </label>
                   <input type="text" class="form-control" name="smiddlenames" 
                   id="firstName" placeholder="Please enter first name" pattern="[A-Za-z]+" title="only letters" required>
               </div>
               <div class="col-md-3">
                   <label for="firstName" class="text-white"><b>SurName *</b> </label>
                   <input type="text" class="form-control" name="slastnames" 
                   id="slastnames" placeholder="Please enter last name" pattern="[A-Za-z]+" title="only letters" required>
               </div>
           </div>
            <div class="form-group row">
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <div class="col-md-4">
                   <label for="firstName" class="text-white"><b>Age *</b> </label>
                   <input type="number" name="age" class="form-control" id="number" min="18" max="100" placeholder="Please enter age" required>
               </div>
            </div>

            <div class="form-group row">
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <div class="col-md-5">
                   <label for="firstName" class="text-white"><b>Permanent address (Proof to be enclosed) *</b> </label>
                   <textarea type="text" height="50" class="form-control" name="paddress" placeholder="Enter address here" pattern="[A-Za-z0-9]+" title="only letters and numbers" required></textarea>
                  
               </div>
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <div class="col-md-5">
                   <label for="firstName" class="text-white"><b>Temporary address (Official address, if any) *</b> </label>
                   <textarea type="text" height="50" class="form-control" name="taddress" placeholder="Enter address here"  pattern="[A-Za-z0-9]+" title="only letters and numbers" required></textarea>
                  
               </div>
                
              
            </div>  

           <div class="form-group row">
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
                <div class="form-group col-md-3">
          <label for="bday" class="text-white"><b>Enter Birth Date *</b></label>
          <input type="date" id="bday" name="bday" class="form-control" required>
       </div>
        <div class="col-md-3">
                   <label for="firstName" class="text-white"><b>Gender *</b> </label>
                   <!--<input type="drop" class="form-control" name="lastname" 
                   id="firstName" placeholder="Please enter last name">-->
                     <select class="form-control" name="gender" required><option value="S">Select</option>
          <option value="M">Male</option>
          <option value="F">Female</option>
          <option value="O">Other</option>
          </select>
               </div>
                <div class="col-md-3">
                   <label for="firstName" class="text-white"><b>Educational qualification *</b> </label>
                   <!--<input type="drop" class="form-control" name="lastname" 
                   id="firstName" placeholder="Please enter last name">-->
                     <select class="form-control" name="education" required><option value="S">Select</option>
                      <option value="M">NONE</option>
          <option value="SSLC">SSLC</option>
          <option value="PUC">PUC</option>
          <option value="DEGREE">DEGREE</option>
          <option value="PG">PG</option>
          </select>
               </div>
           </div> 
           
     

            <div class="form-row">
               &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div class="col-md-3">
                   <label for="firstName" class="text-white"><b>Identification mark(s) *</b> </label>
                   <!--<input type="drop" class="form-control" name="lastname" 
                   id="firstName" placeholder="Please enter last name">-->
                     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text"  class="form-control"  placeholder="Marks" name="mark" pattern="[A-Za-z]+" title="Filled by letters only" required>
               </div>
               <div class="col-md-3">
                   <label for="firstName" class="text-white"><b> Blood Group *</b> </label>
                   <!--<input type="drop" class="form-control" name="lastname" 
                   id="firstName" placeholder="Please enter last name">-->
                     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="blood" class="form-control"  placeholder="Blood-Group" pattern="[A-Za-z]+" title="Filled by letters only" required>
               </div>
               <div class="form-group col-md-3">
          <label for="bday" class="text-white"><b>Enter Date *</b></label>
          <input type="date" id="bday" name="date" class="form-control" required>
       </div>
            </div>
            <br>
            <div class="form-row">
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div class="col-md-3 mb-3">
                
                <label for="validationCustom03" class="text-white"><b>Email Id *</b></label>
                <input type="text" name="email" class="form-control" id="validationCustom03" placeholder="Email-id" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" title="xyz@something.com" required>
                <div class="invalid-feedback" class="text-white">
                  Please provide a valid email.
                </div>
              </div><br>
              <div class="col-md-3 mb-3">
                <label for="validationCustom04" class="text-white"><b>Phone No * </b></label><br>
                <input type="text" name="phone" class="form-control" id="validationCustom04" placeholder="phone no" pattern="[0-9]+" title="numbers only" required>
                <div class="invalid-feedback" class="text-white">
                  Please provide a phone no.
                </div>
              </div>
              
     </div>
     <label class="text-white">
              <h6><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Please Upload Your Documents *</b></h6>
            </label><br>

             <div class="form-row">

              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div class="col-md-3 mb-3">
                <label for="validationCustom03" class="text-white"><b>Upload Your Image *</b></label>
                  <input type="file" name="img_pht" id="img-pht" required>

              </div>
              
              <div class="col-md-3 mb-3">
                <label for="validationCustom05" class="text-white"><b>Upload Your Signature *</b></label>
                <input type="file" name="img_sign" class="form-control-file" id="exampleInputFile" aria-describedb="fileHelp" required>
                
              </div>
              
     </div> 
     <br>
     <br>
     <br>
      <div align="center" class="">
     <input type = "Submit" Value = "Submit Application" width="150px" class="btn btn-success" />            
     </div>
   </div>
  
  
   </fieldset>
</form>
</div>



<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row5">
  <div id="copyright" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <p class="fl_left">Copyright &copy; 2018 - All Rights Reserved - <a href="#">CIVIL REGISTRY</a></p>
    
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="layout/scripts/jquery.min.js"></script>
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
</body>
</html>
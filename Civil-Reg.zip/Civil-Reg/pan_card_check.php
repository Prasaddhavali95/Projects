<?php

session_start();
  if(!isset($_SESSION['user']))
  {
    header("Location: index.php");
  }
  $user = $_SESSION['user'];
  if(!isset($_SESSION['user_id']))
  {
    header("Location: index.php");
  }
  $user_id = $_SESSION['user_id'];
      
$servername="localhost";
$username="root";
$password="";
$dbname="civil";
$conn = new mysqli($servername, $username, $password,$dbname);
if ($conn->connect_error)
{
	die("Connection failed:".$conn->connect_error);
}
/*
echo $app_name=$_POST['applicable_name'];
echo $fname=$_POST['firstName']; 
echo $mname=$_POST['middlename'];
echo $lname=$_POST['lastname'];
echo $ageecho=$_POST['age'];
echo $bday=$_POST['bday'];*/
echo $phone_no=$_POST['phone_no'];
/*
echo $pname=$_POST['parentname'];
echo $pmname=$_POST['parentmname'];
echo $plname=$_POST['parentlname'];
echo $building=$_POST['building'];
echo $street=$_POST['street'];
echo $area=$_POST['area'];
echo $city=$_POST['city'];
echo $state=$_POST['state'];
echo $pincode=$_POST['pincode'];

echo $user_id;

$filename = addcslashes($_FILES["file"]["name"]);

$tmpfilename = addcslashes(file_get_contents($_FILES["file"]["tmp_name"]));

$filetype = addcslashes($_FILES["file"]["name"]);

$array = array('jpg','jpeg','png');

$exten = pathinfo($filename,PATHINFO_EXTENTION);

if(!empty($filename))
{
	if (in_array($exten,$array))
	{
	}
	else
	{
		echo "Unsupported format";
	}
}
else
{
	echo "Please Select the photo";
}*/

$sql = " INSERT INTO pan VALUES ('','$_POST[applicable_name]','$_POST[firstName]', '$_POST[middlename]','$_POST[lastname]','$_POST[age]','$_POST[bday]','$_POST[phone_no]',
'$_POST[parentname]','$_POST[parentmname]','$_POST[parentlname]','$_POST[building]','$_POST[street]',
'$_POST[area]','$_POST[city]','$_POST[state]','$_POST[pincode]','$_POST[img_pht]','$_POST[img_sign]',
'$_POST[img_adhar]','$user_id')";

/*
if($sql)
{
	$target_dir = "uploads/";
	$target_file = $target_dir . basename($_FILES["file"]["name"]);
}
$imageFileType = pathinfo($target_file,PATHINFO_EXTENTION);

*/


if ($conn->query($sql) === TRUE) 
{
    echo "Application Submitted";
    header('Location:http://localhost/My_Projects1/home.php');
} 
else
 {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();




?>
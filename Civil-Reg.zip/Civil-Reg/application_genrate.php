<?php
 include_once('config.php');
	 $query = "select * from pan";
 $result=mysql_query($query);
?>

<!DOCTYPE html>
<html>
<head>
	<title>Application view</title>
</head>
<body>

	<table border="1px">
		<tr>
			<th colspan="18"><h2>Pan card Details</h2></th>
		</tr>
		<t>
			<th>applicable_name</th>
			<th>firstname</th>
			<th>middlename</th>
			<th>lastname</th>
			<th>age</th>
			<th>bday</th>
			<th>parentname</th>
			<th>parentmname</th>
			<th>parentlname</th>
			<th>building</th>
			<th>street</th>
			<th>area</th>
			<th>city</th>
			<th>state</th>
			<th>pincode</th>
			<th>id_img</th>
			<th>img_sign</th>
			<th>img_adhar</th>
		</t>
		<?php
			while ($rows=mysql_fetch_assoc($result)) 
			{
		?>
			<tr>
				<td><?php echo $rows['applicable_name']; ?></td>
				<td><?php echo $rows['firstname']; ?></td>
				<td><?php echo $rows['middlename']; ?></td>
				<td><?php echo $rows['lastname']; ?></td>
				<td><?php echo $rows['age']; ?></td>
				<td><?php echo $rows['bday']; ?></td>
				<td><?php echo $rows['parentname']; ?></td>
				<td><?php echo $rows['parentmname']; ?></td>
				<td><?php echo $rows['parentlname']; ?></td>
				<td><?php echo $rows['building']; ?></td>
				<td><?php echo $rows['street']; ?></td>
				<td><?php echo $rows['area']; ?></td>
				<td><?php echo $rows['city']; ?></td>
				<td><?php echo $rows['state']; ?></td>
				<td><?php echo $rows['pincode']; ?></td>
				<td><?php echo $rows['id_img']; ?></td>
				<td><?php echo $rows['img_sign']; ?></td>
				<td><?php echo $rows['img_adhar']; ?></td>

			</tr>
		<?php
		
		}

		?>	
	</table>
	</table>

</body>
</html>
<?php
	include_once('db.php');
	
	$sql="insert into category(ids,category_id,category_name) 
	values('','".$_POST['id']."','".$_POST['name']."')";
	  if(!mysqli_query($con,$sql))
	  {
		echo"<script> alert('Category Id/Name are Same! Please change it');</script>";
		echo"<script> window.location='categoryadd.php';</script>";
	  }
	  else
	  {
		echo"<script> alert('Category Added!');</script>";
		echo"<script> window.location='category.php';</script>";
	  }
mysqli_close($con);
?>

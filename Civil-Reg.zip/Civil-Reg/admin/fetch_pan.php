<?php
	include_once('db.php');
	$sql1="select * from pan where pan_id='".$_GET['fetch_pan']."'";
	$result1=mysqli_query($con,$sql1);
	echo json_encode(mysqli_fetch_array($result1));
?>
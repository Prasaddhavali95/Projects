<?php
	include_once('db.php');
	include_once('sidebar.php');
?>

<section id="main-content">
	<section class="wrapper">

		  <div class="row">
			<div class="col-lg-11 main-chart">
			  <div class="row mtbox">
					<div class="col-md-2 col-sm-2 col-md-offset-1 box0">
						
							
					</div>
										
					<div class="col-md-2 col-sm-2 box0">
						
							
					</div>
				
				</div><!-- /row mt -->	

			  </div><!-- /col-lg-9 END SECTION MIDDLE -->
			  
			  

		  </div>
	</section>
</section>
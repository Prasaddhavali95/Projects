<?php

	include_once("db.php");
	//session_start();
	
	$sql="select * from admin where username='".$_POST['id']."' and password='".$_POST['password']."'";
	//echo $sql;
	$result=mysqli_query($con,$sql);
	$result1=mysqli_fetch_array($result);
	
	
	if(mysqli_num_rows($result) == 1) //Fetch atleast 1 row from db
	{			
		$_SESSION['SESS'] = $_POST['id'];
		//$_SESSION['name'] = $result1[0];
		echo "<script>window.location = 'admin_dashboard.php';</script>"; //Login Successful
	}
	else
	{
		echo "<script>alert('Invalid Details');</script>";
		echo "<script>window.location = 'index.php';</script>";
	}
	mysqli_close($con);
?>
<?php
	include_once('db.php');
	$sql1="select * from voter where voter_id='".$_GET['fetch_voter']."'";
	$result1=mysqli_query($con,$sql1);
	echo json_encode(mysqli_fetch_array($result1));
?>
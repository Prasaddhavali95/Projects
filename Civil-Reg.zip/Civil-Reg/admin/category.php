<?php
	include_once('db.php');
	include_once('sidebar.php');
?>

<body onload="addDate()">
<section id="main-content">
	<section class="wrapper">
		<!-- BASIC FORM ELELEMNTS -->
		<div class="row mt">
		<div class="col-lg-1"></div>
			<div class="col-lg-10">
			  <div class="form-panel">
				  <center><h4 class="mb"><i class="fa fa-angle-right"></i> New Category </center></h4>
				  <form class="form-horizontal style-form" action="category_ins.php" method="post" enctype="multipart/form-data">
					<?php
						include_once('db.php');
						$sql="select max(category_id) from category";
						$result1=mysqli_query($con,$sql);
						$result=mysqli_fetch_array($result1);
						$result2=$result[0]+1;
						//echo $result2;
					?>	
					  <div class="form-group">
						  <label class="col-sm-2 col-sm-2 control-label">Category Id</label>
						  <div class="col-sm-10">
							<input type="text" autofocus class="form-control" name="id" id="id" value="<?php echo $result2?>" readonly>
						  </div>
					  </div>

					  <div class="form-group">
						  <label class="col-sm-2 col-sm-2 control-label">Category Name</label>
						  <div class="col-sm-10">
								<input type="text" autofocus class="form-control" name="name" id="name">
						  </div>
					  </div>
					  
					<p align="center"><button type="submit" class="btn btn-theme04"><i class="fa fa-check"></i> ADD </button></p>
				  </form>
			  </div>
			</div><!-- col-lg-12-->      	
		</div><!-- /row -->
	</section>
</section>

<script>
	function readURL(input)
	{
		if (input.files && input.files[0])
		{
			var reader = new FileReader();
			reader.onload = function (e)
			{
				$('#pics').attr('src', e.target.result);
			};
			reader.readAsDataURL(input.files[0]);
		}
	}
</script>


</body>
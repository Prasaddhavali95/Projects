<?php
	include_once('db.php');
	$sql1="select * from dl where dl_id='".$_GET['fetch_dl']."'";
	$result1=mysqli_query($con,$sql1);
	echo json_encode(mysqli_fetch_array($result1));
?>
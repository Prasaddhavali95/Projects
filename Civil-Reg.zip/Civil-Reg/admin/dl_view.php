<?php
	include_once('db.php');
	include_once('sidebar.php');
?>


<body onload="addDate()">
<section id="main-content">
	  <section class="wrapper">
		
		<!-- BASIC FORM ELELEMNTS -->
		<div class="row mt">
			  <div class="form-panel">
				<center><h4 class="mb"><i class="fa fa-angle-right"></i> View DL Application </center></h4>
						<table class="table table-bordered">
							<tr class="warning">
								
								<th></th>
								<th>DL ID</th>
								<th>Fullname</th>
								<th>Age</th>
								<th>T Address</th>
								<th>P Address</th>
								<th>Birthday</th>
								<th>Gender</th>
								<th>Education</th>
								<th>Contact</th>
							</tr>

							<?php
								$cnt = 1;
								$qry = "select * from dl";
								$res = mysqli_query($con,$qry);
																	
								while($result = mysqli_fetch_array($res))
								{
									echo'
										<tr>
											<td><a onclick=fetch_data("'.$result[0].'") style="cursor:pointer;"> Approve</a></td>
											<td>'.$result[0].'</td>
											<td>'.$result[2].' '.$result[4].'</td>
											<td>'.$result[8].'</td>
											<td>'.$result[10].'</td>
											<td>'.$result[9].'</td>
											<td>'.$result[11].'</td>
											<td>'.$result[12].'</td>
											<td>'.$result[13].'</td>
											<td>'.$result[18].'</td>
										</tr>';
										$cnt = $cnt + 1;
								}
							?>
						</table>
					</div>  	
		</div><!-- /row -->

	</section>
</section>


<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Send Mail</h4>
      </div>
      <div class="modal-body">
        <form action="fetch_dlupdate.php" method="post">
			<input type="hidden" id="cid" readonly class="form-control" name="cid">
			
			<label class="form-label">Email</label>		
				<input type="text" id="email" class="form-control" name="email" readonly>
			
		  </div>
		  <div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			<button type="submit" class="btn btn-primary">Send Mail</button>
		</form>
      </div>
    </div>
  </div>
</div>


<script language="javascript">

	function fetch_data(rec_data)
	{
		$.ajax({
					type: "GET",
					url: "fetch_dl.php",
					data: "fetch_dl="+rec_data,
					dataType:"json",
			
					success: function(data)
					{
						//document.getElementById('ids').value=data[0];
						document.getElementById('cid').value=data[0];
						document.getElementById('email').value=data[17];
						
						$('#myModal').modal('show');

					}, error:function(e,x)
					{
						alert(e.status);
					}
					
				});
					return false;
	}
</script>
</body>
<?php

	include_once("db.php");

	$mail = $_POST['email'];

	email_send($_POST['email']);
	echo "<script>alert('Confirmation is Sent To Mail-ID');</script>";
	echo "<script>window.location = 'dl_view.php';</script>";

	
	
function email_send($mail)
{
	$content="Application For Driving License Has Been Approved! Thank You";
	//echo $content;
	$mail_to = $mail;
	$mail_sub = "Confirmation";
	$mail_content = $content;
	$From_name="No-Reply";
		
	require_once('PHPMailer-master/class.phpmailer.php');
	$mail = new PHPMailer(true);
	$mail->IsSMTP(); // telling the class to use SMTP
	
	try
	{
		$mail->Host       = "smtp.gmail.com";   // SMTP server
		$mail->SMTPAuth   = true;              // enable SMTP authentication
		$mail->SMTPSecure = "ssl";            // sets the prefix to the servier  
		$mail->Port       = 465;             // set the SMTP port for the GMAIL
  
		$mail->Username   = "plzdonotreplyback@gmail.com";  // GMAIL username
		$mail->Password   = "plzdonotreplyback2423479";            // GMAIL password
		$mail->FromName = "No-Reply";
		$mail->AddReplyTo("plzdonotreplyback@gmail.com","No-Reply");
		$mail->addAddress($mail_to,"User 1");
		$mail->Subject = $mail_sub;
		$mail->AltBody = 'To view the message, please use an HTML compatible email viewer!'; // 
		$mail->Body = $mail_content;
		if($mail->Send())
		{
			
		}
		else
		{
			
		}
	}
	catch (phpmailerException $e) 
	{
		echo $e->errorMessage(); 
	} 
	catch (Exception $e) 
	{
		echo $e->getMessage(); 
	} 
}
?>
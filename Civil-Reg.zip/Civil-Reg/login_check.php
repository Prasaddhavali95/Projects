
<?php


session_start();

	mysql_connect("localhost","root","")or die("cannot connect");
	mysql_select_db("civil")or die("Cannot select");
	
	$email = $_POST['email'];
	$Password = $_POST['password'];
	

	echo $email;
	echo $Password;

	$sql = "select count(*) from registr where email='$email' 
			and password='$Password';";
	$user_name_id_sql = "select username, user_id from registr where email='$email' 
			and password='$Password';";
	
	$result = mysql_query($sql);	
	$user_name_id_result = mysql_query($user_name_id_sql);
	
	while($out = mysql_fetch_row($result))
	{
		$count = $out[0];
	}
	
	while($out2 = mysql_fetch_row($user_name_id_result))
	{
		$count2 = $out2[0];
		$count3 = $out2[1];
	}

	if($count == 0)
	{
		$message = "Username or Password invalid";
		$encode_msg=base64_encode($message);
		
		session_destroy();
		header("Location: login.php?msg1=$encode_msg");
	}
	else
	{
		$_SESSION['user'] = $count2;
		$_SESSION['user_id'] = $count3;
		header("Location: home.php");
	}













/*
$servername="localhost";
$username="root";
$password="";
$dbname="civil";
$conn = new mysqli($servername, $username, $password,$dbname);
if ($conn->connect_error)
{
	die("Connection failed:".$conn->connect_error);
}

$log_email = $_POST['email'];
$log_password = $_POST['password'];


echo $log_email;
echo $log_password;
/*



else
{
	$sql="select * from registr where email='$_POST[email]'and password = '$_POST[password]'";
	$result = mysqli_query($conn,$sql);
	if(!$row = mysqli_fetch_array($result))
	 {
		echo "Welcome to '$_POST[email]'";
		echo "<script> window.location='home.html';</script>";
	}
	else
	{
		echo "<script>alert('Provide valid email and password');</script>";
		
  		echo "<script> window.location='login.php';</script>";
	}
$conn->close();
}*/




?>

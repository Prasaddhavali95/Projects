<?php

$servername="localhost";
$username="root";
$password="";
$dbname="civil";
$conn = new mysqli($servername, $username, $password,$dbname);
if ($conn->connect_error)
{
	die("Connection failed:".$conn->connect_error);
}

$query="select * from pan";
$result = mysqli_query($conn, $query);


$pancard=$_POST["pancard"];
echo $pan;

?>
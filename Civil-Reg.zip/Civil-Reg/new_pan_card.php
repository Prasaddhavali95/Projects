<?php

session_start();
  if(!isset($_SESSION['user']))
  {
    header("Location: index.php");
  }
  $user = $_SESSION['user'];
  if(!isset($_SESSION['user_id']))
  {
    header("Location: index.php");
  }
  $user_id = $_SESSION['user_id'];

      include "config.php";  // including configuration file
?>
<!DOCTYPE html>

<html>
<head>
<title>Civil Registry</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">

    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <script src="bootstrap/js/jquery.min.js"></script>
  <script src="bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="validation.js"></script>
</head>
<body id="top">

<div class="wrapper row0">
  <div id="topbar" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div class="fl_left">
      <ul class="nospace">
        <li><a href="#"><i class="fa fa-lg fa-home"></i></a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Contact</a></li>
        
      </ul>
    </div>
    <div class="fl_right">
      <ul class="nospace">
        <li><i class="fa fa-phone"></i> +91 8123400951</li>
        <li><i class="fa fa-envelope-o"></i> info@civil.com</li>
        <li><div class = "right"> Welcome <?php echo $_SESSION['user']?>|<a href = "logout.php">Logout</a></div></li>
      </ul>
    </div>
    <!-- ################################################################################################ -->
  </div>
</div>

<div class="wrapper row1">
  <header id="header" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div id="logo" class="fl_left">
      <h1><a href="home.php">CIVIL REGISTRY</a></h1>
      <p></p>
    </div>
    <!-- ################################################################################################ -->
    <nav id="mainav" class="fl_right">
      <ul class="clear">
        <li class="active"><a href="home.php">Home</a></li>
        
        <li><a class="drop" href="#">Services</a>
          <ul>
            <li><a href="new_pan_card.php">APPLY PAN CARD</a></li>
             <li><a href="new_voter_id.php">APPLY VOTER ID</a></li>
               <li><a href="new_dl.php">APPLY DRIVING LICENCE</a></li>
          </ul>
        </li>
     
        
      </ul>
    </nav>
    <!-- ################################################################################################ -->
  </header>
</div>

<div class="wrapper bgded overlay" style="background-image:url('images/demo/backgrounds/heres-how-you-can-check-if-your-pan-card-is-active-1400x653-1502186473_1100x513.jpg');">
  <div id="pageintro" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <article>
      <div>
        <p class="heading">"Apply here for Your"</p>
        <h2 class="heading">New Pan Card </h2>
        <p>.</p>
      </div>	
    </article>
    <!-- ################################################################################################ -->
  </div>
</div>
<br>

<div class="wrapper bgded overlay" style="background-image:url('images/demo/backgrounds/Batman_Amoled-wallpaper-11337056.jpg');">
<form action="pan_card_check.php" method="Post" name="myForm" onsubmit="return validation()" enctype="multipart/form-data">
 <div id="pageintro" class="hoc clear"> 
       <fieldset><br>
           <legend align="center" class="text-white"><h3>Applying For Pan Card</h3></legend>
            <div class="checkbox">
            <label class="text-white">
              <b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Please select the title as applicable *</b>
            </label><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               <label class="text-white">
                   <input type="checkbox" value="Shri" name="applicable_name" required>
                   Shri
               </label>&nbsp;&nbsp;
               <label class="text-white">
                   <input type="checkbox" value="Smt." name="applicable_name">
                  Smt.
               </label>&nbsp;&nbsp;
               <label class="text-white">
                   <input type="checkbox" value=" Kumari" name="applicable_name">
                   Kumari
               </label>&nbsp;&nbsp;
               <label class="text-white">
                   <input type="checkbox" value="M/s" name="applicable_name">
                   M/s
               </label>&nbsp;&nbsp;
               <label class="text-white">
                   <input type="checkbox" value="Kumar" name="applicable_name">
                   Kumar
               </label>
           </div>
           <div class="form-group row">
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <div class="col-md-3">
                   <label for="firstName" class="text-white"><b>First Name *</b> </label>
                   <input type="text" class="form-control" name="firstName" 
                   id="firstName" placeholder="Please enter first name" pattern="[A-Za-z]+" title="only letters" required>
               </div>
               <div class="col-md-3">
                   <label for="firstName" class="text-white"><b>Middle Name *</b> </label>
                   <input type="text" class="form-control" name="middlename" 
                   id="firstName" placeholder="Please enter middle name" pattern="[A-Za-z]+" title="only letters" required>
               </div>
               <div class="col-md-3">
                   <label for="firstName" class="text-white"><b>Last Name *</b> </label>
                   <input type="text" class="form-control" name="lastname" 
                   id="firstName" placeholder="Please enter last name" pattern="[A-Za-z]+" title="only letters" required>
               </div>
           </div>
           <div class="form-group row">
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <div class="col-md-4">
                   <label for="firstName" class="text-white"><b>Age *</b> </label>
                   <input type="number" name="age" class="form-control" id="number" min="18" max="100" placeholder="Please enter age" required>
               </div>
                <div class="form-group col-md-3">
			    <label for="bday" class="text-white"><b>Enter Birth Date *</b></label>
			    <input type="date" id="bday" name="bday" class="form-control" required>
 			 </div>
       <div class="form-group col-md-3">
          <label for="phone_no" class="text-white"><b>Phone Number *</b></label>
          <input type="text" id="phone_no" name="phone_no" class="form-control" pattern="^\d{10}$" title="10 numeric characters only" required>
       </div>
           </div> 
           <label class="text-white">
              <b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Please Enter Parents Details *</b>
            </label><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
           <div class="form-group row">
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <div class="col-md-3">
                   <label for="firstName" class="text-white"><b>First Name *</b> </label>
                   <input type="text" class="form-control" name="parentname"
                    placeholder="Please enter first name" pattern="[A-Za-z]+" title="only letters" required>
               </div>
               <div class="col-md-3">
                   <label for="firstName" class="text-white"><b>Middle Name *</b> </label>
                   <input type="text" class="form-control" name="parentmname" 
                    placeholder="Please enter middle name" pattern="[A-Za-z]+" title="only letters" required>
               </div>
               <div class="col-md-3">
                   <label for="firstName" class="text-white"><b>Last Name *</b> </label>
                   <input type="text" class="form-control" name="parentlname" 
                   placeholder="Please enter last name" pattern="[A-Za-z]+" title="only letters" required>
               </div>
           </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          	
          	<label for="validationCustom03" class="text-white"><b>Residental Address *</b></label><br>
           <div class="form-row">
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div class="col-md-3 mb-3">
                
                <label for="validationCustom03" class="text-white"><b>Name of Building/Village *</b></label>
                <input type="text" name="building" class="form-control"  placeholder="Name of Priemises /Building/Village" pattern="[A-Za-z][A-Za-z0-9-_|/.\s]{5.20}$" title="Enter House No" required>
                <div class="invalid-feedback" class="text-white">
                  Please provide a valid address.
                </div>
              </div><br>
              <div class="col-md-3 mb-3">
                <label for="validationCustom04" class="text-white"><b>Road/Street/Lane/Post Office * </b></label><br>
                <input type="text" name="street" class="form-control" id="validationCustom04" placeholder="Road/Street/Lane/Post Office" pattern="[A-Za-z][A-Za-z0-9-_|/.\s]+" title="only letters" required>
                <div class="invalid-feedback" class="text-white">
                  Please provide a Street.
                </div>
              </div>
              <div class="col-md-3 mb-3">
                <label for="validationCustom05" class="text-white"><b>Area/Locality/Taluka/Sub-Divison</b></label>
                <input type="text" class="form-control" name="area" id="validationCustom05" placeholder="Area/Locality/Taluka/Sub-Divison" pattern="[A-Za-z][A-Za-z0-9-_|/.\s]+" title="only letters" required>
                <div class="invalid-feedback" class="text-white">
                  Please provide a valid Area.
                </div>
              </div>
 		 </div>

           
           <div class="form-row">
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div class="col-md-3 mb-3">
                <label for="validationCustom03" class="text-white"><b>City *</b></label>
                <input type="text" name="city" class="form-control" id="validationCustom03" placeholder="City" pattern="[A-Za-z]+" title="only letters" required>
                <div class="invalid-feedback">
                  Please provide a valid city.
                </div>
              </div>
              <div class="col-md-3 mb-3">
                <label for="validationCustom04" class="text-white"><b>State * </b></label>
                <input type="text" name="state" class="form-control" id="validationCustom04" placeholder="State" pattern="[A-Za-z]+" title="only letters" required>
                <div class="invalid-feedback">
                  Please provide a valid state.
                </div>
              </div>
              <div class="col-md-3 mb-3">
                <label for="validationCustom05" class="text-white"><b>PinCode *</b></label>
                <input type="text" name="pincode" class="form-control" id="validationCustom05" placeholder="pincode" pattern="[0-9]+" title="numbers only" required>
                <div class="invalid-feedback">
                  Please provide a valid pincode.
                </div>
              </div>
 		 </div>

 		 <label class="text-white">
              <h6><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Please Upload Your Documents *</b></h6>
            </label><br>

           <!--  <div class="form-row">
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div class="col-md-3 mb-3">
                <label for="validationCustom03" class="text-white"><b>Upload Image *</b></label>
                  <input type="file" name="id_img" class="form-control-file" id="exampleInputFile" aria-describedb="fileHelp" required>
              </div>
              <div class="col-md-3 mb-3">
                <label for="validationCustom04" class="text-white"><b>Upload Signature * </b></label>
                  <input type="file" name="img_sign" class="form-control-file" id="exampleInputFile" aria-describedb="fileHelp" required>
                  
                
              </div>
              <div class="col-md-3 mb-3">
                <label  class="text-white"><b>Upload Adhar *</b></label>
                <input type="file" name="img_adhar" class="form-control-file" id="exampleInputFile" aria-describedb="fileHelp" required>
                
              </div>
 		 </div>	-->

     <!-- <form action="upload.php" align="center" method="post" enctype="multipart/form-data">-->
      <div class="form-row" >
        <div class="col-md-3 mb-3" >
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Select image to upload:</b> 
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="file" align="center" name="img_pht" id="img_pht">     
        </div> 
      <!-- </form>-->
      <!-- <form action="upload.php" align="center" method="post" enctype="multipart/form-data">-->
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Select Signature to upload:</b> 
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="file" align="center" name="img_sign" id="img_sign">

      <!-- </form>-->
      <!-- <form action="upload.php" align="center" method="post" enctype="multipart/form-data"> -->
        
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Select Adhar to upload:</b> 
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="file" align="center" name="img_adhar" id="img_adhar">   
      </div>   
      <!-- </form>-->
 		 <br>
 		 <br>
 		  <div align="center" class="">
	 	 <input type = "Submit" Value = "Submit Application" width="150px" class="btn btn-success" />            
     </div>
	 </div>
   </fieldset>
</form>
</div>



<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row5">
  <div id="copyright" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <p class="fl_left">Copyright &copy; 2018 - All Rights Reserved - <a href="#">CIVIL REGISTRY</a></p>
    
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="layout/scripts/jquery.min.js"></script>
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
</body>
</html>
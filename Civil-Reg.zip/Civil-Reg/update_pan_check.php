<?php

session_start();
  if(!isset($_SESSION['user']))
  {
    header("Location: index.php");
  }
  $user = $_SESSION['user'];
  if(!isset($_SESSION['user_id']))
  {
    header("Location: index.php");
  }
  $user_id = $_SESSION['user_id'];

      include "config.php";  // including configuration file



$servername="localhost";
$username="root";
$password="";
$dbname="civil";
$conn = new mysqli($servername, $username, $password,$dbname);
if ($conn->connect_error)
{
  die("Connection failed:".$conn->connect_error);
}

 $app_name=$_POST['applicable_name'];
 $fname=$_POST['firstName']; 
 $mname=$_POST['middlename'];
 $lname=$_POST['lastname'];
 $age=$_POST['age'];
 $bday=$_POST['bday'];
 $phone_no=$_POST['phone_no'];
 $pan_id=$_POST['txthidden'];
 $pname=$_POST['parentname'];
 $pmname=$_POST['parentmname'];
 $plname=$_POST['parentlname'];
 $building=$_POST['building'];
 $street=$_POST['street'];
 $area=$_POST['area'];
 $city=$_POST['city'];
 $state=$_POST['state'];
 $pincode=$_POST['pincode'];

 $user_id;


$sql = "UPDATE pan SET firstname='$fname', middlename='$mname', lastname='$lname', age='$age', bday='$bday', phone_no='$phone_no', parentname='$pname', parentmname='$pmname', parentlname='$plname', building='$building', street='$street', area='$area', city='$city', state='$state', pincode='$pincode' WHERE pan_id = '$pan_id' ";

//$sql_querry_result = mysql_query($sql);


/*
$sql  = "UPDATE pan SET  firstname = $_POST[firstName], middlename = $_POST[middlename],
lastname = $_POST[lastname], age = $_POST[age], bday = $_POST[bday], phone_no = $phone_no,
parentname = $_POST[parentname],
parentmname = $_POST[parentmname],
parentlname=$_POST[parentlname],
building = $_POST[building],
street = $_POST[street],
area = $_POST[area], 
city = $_POST[city],
state = $_POST[state],
pincode = $_POST[pincode]
WHERE pan_id=$pan_id;";

$sql_exe= mysql_query($sql);
*/


/*
$sql = "INSERT INTO pan VALUES ('','$_POST[applicable_name]', 
'$_POST[firstName]', '$_POST[middlename]','$_POST[lastname]','$_POST[age]','$_POST[bday]','$phone_no','$_POST[parentname]','$_POST[parentmname]','$_POST[parentlname]','$_POST[building]','$_POST[street]','$_POST[area]','$_POST[city]','$_POST[state]','$_POST[pincode]','$_POST[file]','$_POST[file1]','$_POST[file2]','$user_id')";*/

/*
if($sql)
{
  $target_dir = "uploads/";
  $target_file = $target_dir . basename($_FILES["file"]["name"]);
}
$imageFileType = pathinfo($target_file,PATHINFO_EXTENTION);

*/


if ($conn->query($sql) === TRUE) 
{
    echo "Application Submitted";
    header('Location:http://localhost/My_Projects1/status.php');
} 
else
 {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
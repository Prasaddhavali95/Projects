<!DOCTYPE html>
<!--
Template Name: Nodelle
Author: <a href="http://www.os-templates.com/">OS Templates</a>
Author URI: http://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: http://www.os-templates.com/template-terms
-->
<?php
if(isset($_GET['msg1']))
  {
    $msg1=$_GET['msg1'];
    $decode_msg1=base64_decode($msg1);
  }

  if(isset($_GET['msg2']))
  {   
    $msg2=$_GET['msg2'];
    $decode_msg2=base64_decode($msg2);
  }

  if(isset($_GET['msg3']))
  {
    $msg3=$_GET['msg3'];
    $decode_msg3=base64_decode($msg3);
  }
  if(isset($_GET['log']))
  {
    $sent_email=$_GET['log'];
    $sent_email_decode=base64_decode($sent_email);
  }
?>

<html>
<head>
<title>Civil Registry</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">

<meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">

        <!-- CSS -->
        <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=PT+Sans:400,700'>
        <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Oleo+Script:400,700'>
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <script>
  function AllowAlphabet()
  {
    if(!myForm.fname.value.match(/^[a-zA-Z]+$/) && myForm.fname.value != "")
    {
      myForm.fname.value = "";
      myForm.fname.focus();
      alert("Please Enter Alphabets Only");
      return false;
    }
    if(!myForm.lname.value.match(/^[a-zA-Z]+$/) && myForm.lname.value != "")
    {
      myForm.lname.value = "";
      myForm.lname.focus();
      alert("Please Enter Alphabets Only");
      return false;
    }
    if(!myForm.username.value.match(/^[a-zA-Z]+$/) && myForm.username.value != "")
    {
      myForm.username.value = "";
      myForm.username.focus();
      alert("Please Enter Alphabets Only");
      return false;
    } 
  }
  function validateemail()
  {
    var emailid = document.myForm.email.value;
    atpos =  emailid.indexOf("@");
    dotpos  = emailid.indexOf(".");
    
    if(atpos<1 || (dotpos-atpos<2))
    {
      alert("Please Enter correct email Id");
      document.myForm.email.focus();
      return false;
    }
    return true;
  }


  function validate()
    {
      if(document.myForm.fname.value == "")
      {
        alert("Please provide your First name !");
        document.myForm.fname.focus();
        return false;
      }
      else
      {
        var ret = AllowAlphabet();
        if(ret == false)
        {
          return false;
        }
      }
      if(document.myForm.lname.value == "")
      {
        alert("Please provide your last name !");
        document.myForm.lname.focus();
        return false;
      }
      else
      {
        var ret = AllowAlphabet();
        if(ret == false)
        {
          return false;
        }
      }
      if(document.myForm.city.value == "-1")
      {
        alert("Please Select city !");
        document.myForm.city.focus();
        return false;
      }
      if(document.myForm.email.value == "")
      {
        alert("Please provide your Email !");
        document.myForm.email.focus();
        return false;
      }
    else
    {
      var ret = validateemail();
      if(ret == false)
      {
        return false;
      }
      
    }
    if(document.myForm.username.value == "")
        {
           alert("Please provide your Username !");
             document.myForm.username.focus();
            return false;
    }
    else
    {
      var ret = AllowAlphabet();
      if(ret == false)
      {
        return false;
      }
    }
    if(document.myForm.password.value == "")
        {
            alert("Please provide your Password !");
            document.myForm.password.focus();
            return false;
    }
}


</script>
</head>
<body id="top">

<div class="wrapper row0">
  <div id="topbar" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div class="fl_left">
      <ul class="nospace">
        <li><a href="index.html"><i class="fa fa-lg fa-home"></i></a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Contact</a></li>
        <li><a href="login.php">Login</a></li>
        <li><a href="user_registry.php">Register</a></li>
      </ul>
    </div>
    <div class="fl_right">
      <ul class="nospace">
        <li><i class="fa fa-phone"></i> +91 8123400951</li>
        <li><i class="fa fa-envelope-o"></i> info@civil.com</li>
      </ul>
    </div>
    <!-- ################################################################################################ -->
  </div>
</div>

<div class="wrapper row1">
  <header id="header" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div id="logo" class="fl_left">
      <h1><a href="index.html">Civil Registry</a></h1>
      <p></p>
    </div>
    <!-- ################################################################################################ -->
    <nav id="mainav" class="fl_right">
      <ul class="clear">
        <li class="active"><a href="index.html">Home</a></li>
       
          <ul>
            <li><a href="pages/gallery.html">Gallery</a></li>
           
          </ul>
        </li>
         <li><a class="drop" href="#">Services</a>
          <ul>
            <li><a href="user_registry.php">APPLY PAN CARD</a></li>
            <li><a href="user_registry.php"> APPLY VOTER ID</a></li>
            <li><a href="user_registry.php">APPLY PASSPORT</a></li>
            <li><a href="user_registry.php">APPLY ADHAR CARD</a></li>
          </ul>
         
      </ul>
    </nav>
  </header>
</div>


 <div class="register-container container">
            <div class="row">
                <div class="iphone span5">
                    <img src="assets/img/iphone.png" alt="">
                </div>
               <div class="register span6">
                    <form action="registr_check.php" method="post">
                        <h2>REGISTER TO <span class="red"><strong>CIVIL</strong></span></h2>
                        <label for="firstname">First Name</label>
                        <input type="text" id="firstname" name="fname" placeholder="enter your first name..."/>
                        <label for="lastname">Last Name</label>
                        <input type="text" id="lastname" name="lname" placeholder="enter your first name..."/>
                        <label for="username">Username</label>
                        <input type="text" id="username" name="username" placeholder="choose a username..."/>
                        <label for="email">Email</label>
                        <input type="text" id="email" name="email" placeholder="enter your email..." pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$"   />
                        <msg1 color="red">
                        <?php
                        if(isset($decode_msg2))
                          echo $decode_msg2;
                        ?>
                      </msg1>
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" placeholder="choose a password..."/>
                      <!--   <label for="conpassword">Confirm Password</label>
                       <input type="password" id="confirmpass" name="confirmpass"
                         placeholder="Confirm password..." onBlur="confirm_password_validation()"/>-->

                        <button type="submit">SIGN UP</button>
                    </form>
                </div>
            </div>
        </div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row2">
  <div class="hoc container clear"> 
    <!-- ################################################################################################ -->
    <ul class="nospace group cta">
      <li class="one_third first">
        <article><strong class="numb">01</strong>
          <h6 class="heading font-x1"><a href="#">Vulputate ullamcorper</a></h6>
          <p>Rutrum elit nec tincidunt sed aenean aliquet mauris accumsan eget dui id&hellip;</p>
        </article>
      </li>
      <li class="one_third">
        <article><strong class="numb">02</strong>
          <h6 class="heading font-x1"><a href="#">Lobortis condimentum</a></h6>
          <p>Dolor eu suscipit facilisis vestibulum vitae semper nisl vivamus a ligula&hellip;</p>
        </article>
      </li>
      <li class="one_third">
        <article><strong class="numb">03</strong>
          <h6 class="heading font-x1"><a href="#">Malesuada hendrerit</a></h6>
          <p>Nulla ut imperdiet metus aliquam iaculis mi in tortor accumsan at lobortis&hellip;</p>
        </article>
      </li>
    </ul>
    <!-- ################################################################################################ -->
  </div>
</div>


<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row5">
  <div id="copyright" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <p class="fl_left">Copyright &copy; 2018 - All Rights Reserved - <a href="index.html">Civil Registry</a></p>
      
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="layout/scripts/jquery.min.js"></script>
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>

<script src="assets/js/jquery-1.8.2.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.backstretch.min.js"></script>
        <script src="assets/js/scripts.js"></script>
</body>
</html>
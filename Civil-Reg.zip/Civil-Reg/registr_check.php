<?php

mysql_connect("localhost","root","") or die("cannot connect");
	
	mysql_select_db("civil") or die("cannot select DB");
	

	$fname=$_POST['fname'];
	$lname=$_POST['lname'];
	$user_name=$_POST['username'];
	$emailid=$_POST['email'];
	$password=$_POST['password'];


	if(($fname and $lname and $user_name and $emailid and $password)==Null)
	{
		$Message1= "Enter Proper Details";
		$encode1=base64_encode($Message1);
		header("Location: user_registry.php?msg1=$encode1");	
	}
	else if(($fname and $emailid and $password)!=Null)
	{

		//$sql1="select email from root where email=$emailid;";
		$result1=mysql_query("select email from registr where email='$emailid'");
		
		while($output=mysql_fetch_row($result1))
		{
			echo $email_id=$output[0];
		}
		if ($email_id==$emailid)
		{
				$Message2 = "This email already exist try some other";
				$encode2=base64_encode($Message2);
				$encode2_email=base64_encode($emailid);
				header("Location: user_registry.php?msg2=$encode2&log=$encode2_email");
		}
		else 
		{
			$sql="insert into registr values('','$fname','$lname','$user_name','$emailid','$password','');";
			$result=mysql_query($sql);
			$Message ="Registered Successfuly Now Login";
			$encode=base64_encode($Message);
			header("Location: login.php?msg=$encode");
		}

	}





/*
	$servername="localhost";
	$username="root";
	$password="";
	$dbname="civil";
	$conn = new mysqli($servername, $username, $password,$dbname);


	mysql_connect("localhost","root","") or die("cannot connect");
	
	mysql_select_db("civil") or die("cannot select DB");

	if ($conn->connect_error)
	{
		die("Connection failed:".$conn->connect_error);
	}


	$fname=$_POST['fname'];
	$lname=$_POST['lname'];
	$username=$_POST['username'];
	$emailid=$_POST['email'];
	$password=$_POST['password'];


	if(($fname and $lname and $username and $emailid and $password)==Null)
	{
		$Message1= "Enter All Details";
		$encode1=base64_encode($Message1);
		header("Location: user_registry.php?msg1=$encode1");	
	}
	else if(($fname and $emailid and $password)!=Null)
	{


		//$sql1="select email from root where email=$emailid;";
		$result1=mysql_query("select email from registr where email='$emailid'");
		while($output=mysql_fetch_row($result1))
		{
			$email_id=$output[0];
		}
		if($email_id==$emailid)
		{
			$Message2 = "This email already exist try some other";
			$encode2=base64_encode($Message2);
			$encode2_email=base64_encode($emailid);
			header("Location: user_registry.php?msg2=$encode2&log=$encode2_email");
		}
	}
	else 
	{

		$sql="insert into registr values('','$fname','$lname','$username','$emailid','password');";
		$result=mysql_query($sql);
		$Message ="Registered Successfuly Now Login";
		$encode=base64_encode($Message);
		header("Location: login_page.php?msg=$encode");
	}
exit();


	/*

$sql = "INSERT INTO registr VALUES ('','$_POST[fname]', '$_POST[lname]', '$_POST[username]','$_POST[email]','$_POST[password]')";

if ($conn->query($sql) === TRUE) 
{
    //echo "New record created successfully";
    header('Location:http://localhost/My_Projects/login.php');
} 
else
 {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();*/


?>
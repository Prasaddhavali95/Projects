<?php

$servername="localhost";
$username="root";
$password="";
$dbname="civil";
$conn = new mysqli($servername, $username, $password,$dbname);

$query="SELECT * FROM pan";

$result=mysqli_query($conn, $query);

?>
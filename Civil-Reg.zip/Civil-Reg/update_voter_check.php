<?php

session_start();
  if(!isset($_SESSION['user']))
  {
    header("Location: index.php");
  }
  $user = $_SESSION['user'];
  if(!isset($_SESSION['user_id']))
  {
    header("Location: index.php");
  }
  $user_id = $_SESSION['user_id'];

      include "config.php";  // including configuration file



$servername="localhost";
$username="root";
$password="";
$dbname="civil";
$conn = new mysqli($servername, $username, $password,$dbname);
if ($conn->connect_error)
{
  die("Connection failed:".$conn->connect_error);
}

$fname=$_POST['firstname'];
$lname=$_POST['lastname'];
$nsrelative=$_POST['nsrelative'];
$sonof=$_POST['sonof'];
$age=$_POST['age'];
$bday=$_POST['bday'];
$gender=$_POST['gender'];
$building=$_POST['building'];
$town=$_POST['town'];
$area=$_POST['area'];
$city=$_POST['city'];
$state=$_POST['state'];
$pincode=$_POST['pincode'];
$locality=$_POST['locality'];
$village=$_POST['village'];
$postoffice=$_POST['postoffice'];
$city1=$_POST['city1'];
$state2=$_POST['state2'];
$pincode2=$_POST['pincode2'];
$disability=$_POST['disability'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$uploadimg=$_POST['uploadimg'];
$uploadadhar=$_POST['uploadadhar'];

$user_id;


$sql="UPDATE voter SET firstname='$fname', lastname='$lname',nsrelative='$nsrelative', sonof='$sonof', age='$age', bday='$bday', gender='$gender', building='$building', town='$town', area='$area',city='$city', state='$state', pincode='$pincode', locality='$locality', village='$village', postoffice='$postoffice', city1='$city1', state2='$state2',
  pincode2='$pincode2', disability='$disability', email='$email', phone='$phone', uploadimg='$uploadimg', uploadadhar='$uploadadhar' WHERE voter_id = '$voter_id' ";





if ($conn->query($sql) === TRUE) 
{
    echo "Application Submitted";
    header('Location:http://localhost/My_Projects1/status.php');
} 
else
 {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
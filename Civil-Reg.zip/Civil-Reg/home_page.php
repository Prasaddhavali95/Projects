<?php
session_start();
	if(!isset($_SESSION['user']))
	{
		header("Location: index.php");
	}
	$user = $_SESSION['user'];

?>
<html>
<head>
<title>Civil Registry</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row0">
  <div id="topbar" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div class="fl_left">
      <ul class="nospace">
        <li><a href="#"><i class="fa fa-lg fa-home"></i></a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Contact</a></li>
        
      </ul>
    </div>
    <div class="fl_right">
      <ul class="nospace">
        <li><i class="fa fa-phone"></i> +91 8123400951</li>
        <li><i class="fa fa-envelope-o"></i> info@civil.com</li>
        <li><div class = "right"> Welcome <?php echo $_SESSION['name']?>|<a href = "logout.php">Logout</a></div></li>
      </ul>
    </div>

    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row1">
  <header id="header" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div id="logo" class="fl_left">
      <h1><a href="index.html">CIVIL REGISTRY</a></h1>
      <p></p>
    </div>
    <!-- ################################################################################################ -->
    <nav id="mainav" class="fl_right">
      <ul class="clear">
        <li class="active"><a href="index.html">Home</a></li>
        
        <li><a class="drop" href="#">Services</a>
          <ul>
            <li><a href="new_pan_card.php">APPLY PAN CARD</a></li>
             <li><a href="new_voter_Id.php">APPLY VOTER ID</a></li>
               <li><a href="new_dl.php">APPLY DRIVING LICENCE</a></li>
          </ul>
        </li>
        <li><a href="status.php">Application Status</a></li>
        
      </ul>
    </nav>
    <!-- ################################################################################################ -->
  </header>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper bgded overlay" style="background-image:url('images/demo/backgrounds/Vidhana_Soudha_2012.jpg');">
  <div id="pageintro" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <article>
      <div>
        <p class="heading">"Gain from our Perspective"</p>
        <h2 class="heading">BE ALL YOU CAN BE </h2>
        <p>.</p>
      </div>
      
    </article>
    <!-- ################################################################################################ -->
  </div>
</div>

<div class="wrapper row2">
  <div class="hoc container clear"> 
    <!-- ################################################################################################ -->
    <ul class="nospace group cta">
      <li class="one_third first">
        <article><strong class="numb">01</strong>
          <h6 class="heading font-x1"><a >Voter ID</a></h6>
          <p>The Indian voter ID card is an identity document issued by the Election Commission of India which primarily serves as an identity proof for Indian citizens while casting votes in the country's municipal, state, and national elections.&hellip;</p>
        </article>
      </li>
      <li class="one_third">
        <article><strong class="numb">02</strong>
          <h6 class="heading font-x1"><a >Pan Card</a></h6>
          <p> Permanent Account Number (PAN) is a code that acts as an identification for individuals, families and corporates (Indian or Foreign), especially those who pay Income Tax.&hellip;</p>
        </article>
      </li>
      <li class="one_third">
        <article><strong class="numb">03</strong>
          <h6 class="heading font-x1"><a ">Driving Licences</a></h6>
          <p>A driver's license is an official document permitting a specific individual to operate one or more types of motorized vehicles, such as a motorcycle, car, truck, or bus on a public road.&hellip;</p>
        </article>
      </li>
    </ul>
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row3">
  <main class="hoc container clear"> 
    <!-- main body -->
    <!-- ################################################################################################ -->
    <ul class="nospace group services">
      <li class="one_third first btmspace-30">
        <article><a href="new_voter_Id.php">
           <div>
            <img src="images/demo/backgrounds/voter-id-card.jpeg">
          </div>
        </a>
          <h6 class="heading font-x1" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;VOTER CARD</h6>
          <p>voter ID card is an identity document issued by the Election Commission of India&hellip;</p>
        </article>
      </li>
      <li class="one_third btmspace-30">
        <article><a href="new_dl.php"> <div>
            <img src="images/demo/backgrounds/Driving_License_issued_by_the_Transport_department_of_Karnataka_State.jpg">
          </div></a>
          <h6 class="heading font-x1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;DL CARD</h6>
          <p>driver's license is an official document permitting a specific individual to operate&hellip;</p>
        </article>
      </li>
      <li class="one_third btmspace-30">
       <article><a href="new_pan_card.php">
          
           <div>
            <img src="images/demo/backgrounds/heres-how-you-can-check-if-your-pan-card-is-active-1400x653-1502186473_1100x513.jpg"/>
          </div>
        </a>
          <h6 class="heading font-x1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;PAN CARD</h6>
          <p>that acts as an identification for individuals, families and corporates, especially those who pay Income Tax&hellip;</p>
        </article>
      </li>
      
    </ul>
    <!-- ################################################################################################ -->
    <!-- / main body -->
    <div class="clear"></div>
  </main>
</div>

<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row5">
  <div id="copyright" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <p class="fl_left">Copyright &copy; 2018 - All Rights Reserved - <a href="#">CIVIL REGISTRY</a></p>
    
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="layout/scripts/jquery.min.js"></script>
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
</body>
</html>
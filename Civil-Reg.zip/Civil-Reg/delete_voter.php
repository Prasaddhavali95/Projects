<?php
	session_start();

	mysql_connect("localhost","root","") or die("cannot connect");	
	mysql_select_db("civil") or die("cannot select DB");

      include "config.php"; 
	
	$id=$_GET['id'];
	$sql="delete from voter where voter_id=$id";
	$result=mysql_query($sql);
	
	header("Location: display.php");
?>
-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 11, 5018 at 05:55 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40501 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40501 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40501 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40501 SET NAMES utf8 */;

--
-- Database: `civil`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `ids` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY (`ids`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`ids`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `dl`
--

CREATE TABLE IF NOT EXISTS `dl` (
  `dl_id` int(50) NOT NULL AUTO_INCREMENT,
  `names` varchar(50) DEFAULT NULL,
  `firstname` varchar(50) DEFAULT NULL,
  `middlename` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `sfirstname` varchar(50) DEFAULT NULL,
  `smiddlenames` varchar(50) DEFAULT NULL,
  `slastnames` varchar(50) DEFAULT NULL,
  `age` int(5) DEFAULT NULL,
  `paddress` varchar(50) DEFAULT NULL,
  `taddress` varchar(50) DEFAULT NULL,
  `bday` date DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `education` varchar(50) DEFAULT NULL,
  `mark` varchar(50) DEFAULT NULL,
  `blood` varchar(5) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone_no` varchar(50) DEFAULT NULL,
  `img_pht` varchar(50) DEFAULT NULL,
  `img_sign` varchar(50) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`dl_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `dl`
--

INSERT INTO `dl` (`dl_id`, `names`, `firstname`, `middlename`, `lastname`, `sfirstname`, `smiddlenames`, `slastnames`, `age`, `paddress`, `taddress`, `bday`, `gender`, `education`, `mark`, `blood`, `date`, `email`, `phone_no`, `img_pht`, `img_sign`, `user_id`) VALUES
(1, 'a', 'b', 'c', 'd', 'e', 'f', 'g', 11, 'h', 'i', '5018-05-01', 'j', 'k', 'l', 'm', '5018-05-08', 'computronics.belgaum@gmail.com', 'n', 'o', 'p', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pan`
--

CREATE TABLE IF NOT EXISTS `pan` (
  `pan_id` int(11) NOT NULL AUTO_INCREMENT,
  `applicable_name` varchar(5) DEFAULT NULL,
  `firstname` varchar(50) DEFAULT NULL,
  `middlename` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `age` int(5) DEFAULT NULL,
  `bday` date DEFAULT NULL,
  `phone_no` int(50) DEFAULT NULL,
  `parentname` varchar(50) DEFAULT NULL,
  `parentmname` varchar(50) DEFAULT NULL,
  `parentlname` varchar(50) DEFAULT NULL,
  `building` varchar(50) DEFAULT NULL,
  `street` varchar(50) DEFAULT NULL,
  `area` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `pincode` int(5) DEFAULT NULL,
  `img_pht` varchar(50) DEFAULT NULL,
  `img_sign` varchar(50) DEFAULT NULL,
  `img_adhar` varchar(50) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`pan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `registr`
--

CREATE TABLE IF NOT EXISTS `registr` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(50) DEFAULT NULL,
  `lname` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `confirmpass` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `registr`
--

INSERT INTO `registr` (`user_id`, `fname`, `lname`, `username`, `email`, `password`, `confirmpass`) VALUES
(1, 'Computronics', 'Belgaum', 'Computronics', 'computronics.belgaum@gmail.com', '123', '123');

-- --------------------------------------------------------

--
-- Table structure for table `voter`
--

CREATE TABLE IF NOT EXISTS `voter` (
  `voter_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `nsrelative` varchar(50) DEFAULT NULL,
  `sonof` varchar(50) DEFAULT NULL,
  `age` varchar(50) DEFAULT NULL,
  `bday` date DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `building` varchar(50) DEFAULT NULL,
  `street` varchar(50) DEFAULT NULL,
  `town` varchar(50) DEFAULT NULL,
  `area` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `pincode` varchar(5) DEFAULT NULL,
  `locality` varchar(50) DEFAULT NULL,
  `village` varchar(50) DEFAULT NULL,
  `postoffice` varchar(50) DEFAULT NULL,
  `city1` varchar(50) DEFAULT NULL,
  `state2` varchar(50) DEFAULT NULL,
  `pincode2` varchar(5) DEFAULT NULL,
  `disability` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `uploadimg` varchar(50) DEFAULT NULL,
  `uploadadhar` varchar(50) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`voter_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `voter`
--

INSERT INTO `voter` (`voter_id`, `firstname`, `lastname`, `nsrelative`, `sonof`, `age`, `bday`, `gender`, `building`, `street`, `town`, `area`, `city`, `state`, `pincode`, `locality`, `village`, `postoffice`, `city1`, `state2`, `pincode2`, `disability`, `email`, `phone`, `uploadimg`, `uploadadhar`, `user_id`) VALUES
(1, 'a', 'b', 'c', 'd', 'e', '5018-05-08', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'computronics.belgaum@gmail.com', 'u', 'v', 'w', 1);

/*!40501 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40501 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40501 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

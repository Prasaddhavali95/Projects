<?php

session_start();
  if(!isset($_SESSION['user']))
  {
    header("Location: index.php");
  }
  $user = $_SESSION['user'];
  if(!isset($_SESSION['user_id']))
  {
    header("Location: index.php");
  }
  $user_id = $_SESSION['user_id'];

      include "config.php";  // including configuration file



$servername="localhost";
$username="root";
$password="";
$dbname="civil";
$conn = new mysqli($servername, $username, $password,$dbname);
if ($conn->connect_error)
{
	die("Connection failed:".$conn->connect_error);
}

$sql = "INSERT INTO dl VALUES ('','$_POST[names]', 
'$_POST[firstName]', '$_POST[middlename]','$_POST[lastname]','$_POST[sfirstName]', '$_POST[smiddlenames]',
'$_POST[slastnames]','$_POST[age]','$_POST[paddress]','$_POST[taddress]','$_POST[bday]','$_POST[gender]',
'$_POST[education]','$_POST[mark]','$_POST[blood]','$_POST[date]','$_POST[email]','$_POST[phone]',
'$_POST[img_pht]','$_POST[img_sign]','$user_id')";


if ($conn->query($sql) === TRUE) 
{
    echo "New record created successfully";
    header('Location:http://localhost/My_Projects1/home.php');
} 
else
 {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>





















<!--<?php
/*session_start();
$servername="localhost";
$username="root";
$password="";
$dbname="civil";
$conn = new mysqli($servername, $username, $password,$dbname);
if ($conn->connect_error)
{
	die("Connection failed:".$conn->connect_error);
}

if(!isset($_SESSION['user_id']))
	{
		header("Location: index.php");
	}

	$user_id = $_SESSION['user_id'];
*/
/*
$sql = "INSERT INTO dl VALUES ('','$_POST[names]', 
'$_POST[firstName]', '$_POST[middlename]','$_POST[lastname]','$_POST[sfirstName]', '$_POST[smiddlenames]',
'$_POST[slastnames]','$_POST[paddress]','$_POST[taddress]','$_POST[bday]','$_POST[gender]','$_POST[education]',
'$_POST[mark]','$_POST[blood]','$_POST[date]','$_POST[email]','$_POST[phone]','$_POST[img_pht]',
'$_POST[img_sign]','$user_id')";

if ($conn->query($sql) === TRUE) 
{
    echo "New record created successfully";
    header('Location:http://localhost/My_Projects/home.html');
} 
else
 {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>-->
*/
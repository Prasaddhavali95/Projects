<?php
  session_start();
  if(!isset($_SESSION['user']))
  {
    header("Location: index.php");
  }
  $user = $_SESSION['user'];
  if(!isset($_SESSION['user_id']))
  {
  header("Location: index.php");
  }

  $user_id = $_SESSION['user_id'];
      include "config.php";  // including configuration file
?>

<html>
<head>
<title>Civil Registry</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">

    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <script src="bootstrap/js/jquery.min.js"></script>
  <script src="bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="validation.js"></script>
</head>
<body id="top">

<div class="wrapper row0">
  <div id="topbar" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div class="fl_left">
      <ul class="nospace">
        <li><a href="#"><i class="fa fa-lg fa-home"></i></a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Contact</a></li>
        
      </ul>
    </div>
    <div class="fl_right">
      <ul class="nospace">
        <li><i class="fa fa-phone"></i> +91 8123400951</li>
        <li><i class="fa fa-envelope-o"></i> info@civil.com</li>
        <li><div class = "right"> Welcome <?php echo $_SESSION['user']?>|<a href = "logout.php">Logout</a></div></li>
        
      </ul>
    </div>
    <!-- ################################################################################################ -->
  </div>
</div>

<div class="wrapper row1">
  <header id="header" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div id="logo" class="fl_left">
      <h1><a href="home.php">CIVIL REGISTRY</a></h1>
      <p></p>
    </div>
    <!-- ################################################################################################ -->
    <nav id="mainav" class="fl_right">
      <ul class="clear">
        <li class="active"><a href="home.php">Home</a></li>
        
        <li><a class="drop" href="#">Services</a>
          <ul>
            <li><a href="new_pan_card.php">APPLY PAN CARD</a></li>
             <li><a href="new_voter_id.php">APPLY VOTER ID</a></li>
               <li><a href="new_dl.php">APPLY DRIVING LICENCE</a></li>
          </ul>
        </li>
        
        
      </ul>
    </nav>
    <!-- ################################################################################################ -->
  </header>
</div>

<br>
<br>

     <form name="frmdropdown" method="post" >
     <center>
     	  <table border="2">
 <tr align="center">
  
     <th>Applicant Name </th>
   <!--  <th>Middle Name</th>-->
     <th>Last Name</th>
     <th>Age</th>
     <th>Date of Birth</th>
     <th>Mobile No</th>
     <th>Edit</th>
     <th>Delete</th>
     
 </tr> 
 
 <?php
  if($_SERVER['REQUEST_METHOD'] == "POST")
  {
         $phone_no=$_POST["dropdown"]; 

         $pan_table =mysql_query("select phone_no from pan where phone_no=$phone_no");
         $voter_table=mysql_query("select phone from voter where phone=$phone_no");
         $dl_table =mysql_query("select phone from dl where phone=$phone_no");

        while ($pan_row=mysql_fetch_row($pan_table))
        {
           $pan_count=$pan_row[0];
        }
        

        while ($vote_row=mysql_fetch_row($voter_table))
        {
           $vote_count=$vote_row[0];
        }

        /*while ($dl_row=mysql_fetch_row($dl_table))
        {
    		$dl_count=$dl_row[0];
        }*/
        

        if($phone_no=="")  
        { 
             $res=mysql_query("Select * from pan");
        }
        else
        { 
            $res=mysql_query("Select * from pan where  phone_no='".$phone_no."'");

            while($r=mysql_fetch_row($res))
            {
                $record=$r[0];
                $encode= base64_encode($record);
                $view_link="update_pancard.php?id=$encode";
                $delete_link="delete_check.php?id=$record";
 
                echo "<tr align='center'>";
                echo "<td align='center'>$r[2]</td>";
              //  echo "<td width='200'>$r[3]" . " </td>";
                echo "<td alig='center' width='40'> $r[4]</td>";
                echo "<td align='center' width='200'>$r[5]</td>";
                echo "<td width='100' align='center'>$r[6]</td>";
                echo "<td width='100' align='center'>$r[7]</td>";
            ?>
                <td> <a href="<?php echo $view_link; ?>">Edit </a> </td>
                <td> <a href="<?php echo $delete_link; ?>">Delete </a> </td>
            <?php
                echo "</tr>";
            }
        }
       	if ($phone_no=="")
       	{
       		 $res=mysql_query("Select * from voter");
       	}
        else
        {
          $res=mysql_query("Select * from voter where  phone ='".$phone_no."'");

            while($r=mysql_fetch_row($res))
            {
                $record=$r[0];
                $encode= base64_encode($record);
                $view_link="update_voter.php?id=$encode";
                $delete_link="delete_voter.php?id=$record";

                echo "<tr align='center'>";
                echo "<td align='center'>$r[1]</td>";
                echo "<td width='200'>$r[2]" . " </td>";
                echo "<td alig='center' width='40'> $r[5]</td>";
                echo "<td align='center' width='200'>$r[6]</td>";
                echo "<td width='100' align='center'>$r[23]</td>";
               // echo "<td width='100' align='center'>$r[7]</td>";
            ?>
                <td> <a href="<?php echo $view_link; ?>">Edit </a> </td>
                <td> <a href="<?php echo $delete_link; ?>">Delete </a> </td>
            <?php
                echo "</tr>";
            }
            }
        }
   		/*if ($phone_no=="")
       	{
       		 $res=mysql_query("Select * from dl");
       	}
        else
        {
          $res=mysql_query("Select * from dl where  phone ='".$phone_no."'");

            while($r=mysql_fetch_row($res))
            {
                $record=$r[0];
                $encode= base64_encode($record);
                $view_link="update_dl.php?id=$encode";
                $delete_link="delete_dl.php?id=$record";

                echo "<tr align='center'>";
                echo "<td align='center'>$r[1]</td>";
                echo "<td width='200'>$r[2]" . " </td>";
                echo "<td alig='center' width='40'> $r[5]</td>";
                echo "<td align='center' width='200'>$r[6]</td>";
                echo "<td width='100' align='center'>$r[23]</td>";
               // echo "<td width='100' align='center'>$r[7]</td>";
            ?>
                <td> <a href="<?php echo $view_link; ?>">Edit </a> </td>
                <td> <a href="<?php echo $delete_link; ?>">Delete </a> </td>
            <?php
                echo "</tr>";
            }
          
        }*/
?>
  </table>
 </center>
</form>
</body>
</html>
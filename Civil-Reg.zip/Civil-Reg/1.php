<form>
	<select name="taskoption">
		<option value="select your choice" selected>Select your choice	</option>

		<?php
		include 'config.php';
		?>
		<?php 
				while ($row1 = mysql_fetch_array($resullt)) ;;?>
				<option value="<?php echo $row1[0]; ?>">
					<?php
							echo $row1[1];
					?>

				</option>
	<?php endwhile; ?>
	</select>

</form>
<?php

session_start();
  if(!isset($_SESSION['user']))
  {
    header("Location: index.php");
  }
  $user = $_SESSION['user'];
  if(!isset($_SESSION['user_id']))
  {
    header("Location: index.php");
  }
  $user_id = $_SESSION['user_id'];

      include "config.php";  // including configuration file
?>
<!DOCTYPE html>

<html>
<head>
<title>Civil Registry</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">

    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <script src="bootstrap/js/jquery.min.js"></script>
  <script src="bootstrap/js/bootstrap.min.js"></script>

</head>
<body id="top">

<div class="wrapper row0">
  <div id="topbar" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div class="fl_left">
      <ul class="nospace">
        <li><a href="#"><i class="fa fa-lg fa-home"></i></a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Contact</a></li>
        
      </ul>
    </div>
    <div class="fl_right">
      <ul class="nospace">
        <li><i class="fa fa-phone"></i> +91 8123400951</li>
        <li><i class="fa fa-envelope-o"></i> info@civil.com</li>
        <li><div class = "right"> Welcome <?php echo $_SESSION['user']?>|<a href = "logout.php">Logout</a></div></li>

      </ul>
    </div>
    <!-- ################################################################################################ -->
  </div>
</div>

<div class="wrapper row1">
  <header id="header" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div id="logo" class="fl_left">
      <h1><a href="home.php">CIVIL REGISTRY</a></h1>
      <p></p>
    </div>
    <!-- ################################################################################################ -->
    <nav id="mainav" class="fl_right">
      <ul class="clear">
        <li class="active"><a href="home.php">Home</a></li>
        
        <li><a class="drop" href="#">Services</a>
          <ul>
            <li><a href="new_pan_card.php">APPLY PAN CARD</a></li>
             <li><a href="new_voter_id.php">APPLY VOTER ID</a></li>
               <li><a href="new_dl.php">APPLY DRIVING LICENCE</a></li>
          </ul>
        </li> 
      </ul>
    </nav>
  </header>
</div>

<form class="container" name="frmdropdown" method="post" action="display.php">

  <div class="card">
      <div class="form-group">
          <label align="center"><h4><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  Application Status</b></h4></label>
      </div>
     
      <div class="form-group row">
         <label><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Application Type</b></label>
         &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;
          <div class="form-group col-md-3" align="center">

                         <select class="form-control" name="dropdown" required>
                          <option value="select" name="select">Select</option>                                   
                          <?php
                        
                            if(!isset($_SESSION['user_id']))
                            {
                            header("Location: index.php");
                            }

                            $user_id = $_SESSION['user_id'];
                           

                            $pan_tab=mysql_query("select phone_no from pan where user_id=$user_id;");
                            
                              while ($pan_result=mysql_fetch_row($pan_tab)) 
                              {
                                 $count_pan=$pan_result[0];
                                 echo "<option value='$pan_result[0]'> PAN Card Status </option> ";
                              }

                              $voter_tab=mysql_query("select phone from voter where user_id=$user_id;");
                              
                              while ($vote_result=mysql_fetch_row($voter_tab)) 
                              {
                                 $count_vote=$vote_result[0];
                                 echo "<option value='$vote_result[0]'> Voter ID status </option> ";
                              }
                              
                             /* $dl_table=mysql_query("select phone from dl where user_id=$user_id;");
                              
                              while ($dl_result=mysql_fetch_row($dl_table))
                              {
                                $count_dl=$dl_result[0];
                                echo "<option value='$dl_result[0]'>DL status</option>";
                              }*/
                            /*session_start();
                            if(!isset($_SESSION['user_id']))
                            {
                            header("Location: index.php");
                            }

                            $user_id = $_SESSION['user_id'];
                            echo $user_id;

                            echo $pan_tab=mysql_query("select phone_no from pan where pan_id=$user_id;");
                              /* $dd_res=mysql_query("Select DISTINCT  phone_no from pan");

/*
                               while($r=mysql_fetch_row($dd_res))
                               { 
                                     echo "<option value='$r[0]'> $r[0] </option>";
                               }*/
                           ?>
                        </select>
        </div>
      </div>
      <div class="form-group row">
           &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div class="form-group col-md-3" >
                    <input type="Submit"  name="Submit" value="Submit" class="btn btn-success">
                  
        </div>
      </div>
  </div>
</form>


<br>
<div class="wrapper row5">
  <div id="copyright" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <p class="fl_left">Copyright &copy; 2018 - All Rights Reserved - <a href="home.html">CIVIL REGISTRY</a></p>
    
    <!-- ################################################################################################ -->
  </div>
</div>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="layout/scripts/jquery.min.js"></script>
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
</body>
</html>
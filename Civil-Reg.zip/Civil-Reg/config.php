<?php
 $databaseHost = "localhost"; 
 $databaseUser = "root";
 $databasePassword = "";
 $databaseName = "civil";
        
      $con=mysql_connect($databaseHost ,$databaseUser ,$databasePassword )or die ('Connection Error');
      mysql_select_db("civil",$con) or die ('Database Error');
mysql_connect("localhost","root","")or die("cannot connect");
	mysql_select_db("civil")or die("Cannot select");


      
 ?>
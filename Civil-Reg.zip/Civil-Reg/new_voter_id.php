<?php

session_start();
  if(!isset($_SESSION['user']))
  {
    header("Location: index.php");
  }
  $user = $_SESSION['user'];
  if(!isset($_SESSION['user_id']))
  {
    header("Location: index.php");
  }
  $user_id = $_SESSION['user_id'];

      include "config.php";  // including configuration file
?>

<!DOCTYPE html>



<html>
<head>
<title>Civil Registry</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">

    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <script src="bootstrap/js/jquery.min.js"></script>
  <script src="bootstrap/js/bootstrap.min.js"></script>
</head>
<body id="top">

<div class="wrapper row0">
  <div id="topbar" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div class="fl_left">
      <ul class="nospace">
        <li><a href="#"><i class="fa fa-lg fa-home"></i></a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Contact</a></li>
        
      </ul>
    </div>
    <div class="fl_right">
      <ul class="nospace">
        <li><i class="fa fa-phone"></i> +91 8123400951</li>
        <li><i class="fa fa-envelope-o"></i> info@civil.com</li>
        <li><div class = "right"> Welcome <?php echo $_SESSION['user']?>|<a href = "logout.php">Logout</a></div></li>
      </ul>
    </div>
    <!-- ################################################################################################ -->
  </div>
</div>

<div class="wrapper row1">
  <header id="header" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <div id="logo" class="fl_left">
      <h1><a href="home.html">CIVIL REGISTRY</a></h1>
      <p></p>
    </div>
    <!-- ################################################################################################ -->
    <nav id="mainav" class="fl_right">
      <ul class="clear">
        <li class="active"><a href="home.php">Home</a></li>
        <li><a class="drop" href="#">Pages</a>
          <ul>
            <li><a href="#">Gallery</a></li>
          </ul>
        </li>
        <li><a class="drop" href="#">Services</a>
          <ul>
            <li><a href="new_pan_card.php">APPLY PAN CARD</a></li>
             <li><a href="new_voter_id.php">APPLY VOTER ID</a></li>
               <li><a href="new_dl.php">APPLY DRIVING LICENCE</a></li>
          </ul>
        </li>
        <li><a href="#">PORTFOLIO</a></li>
        
      </ul>
    </nav>
    <!-- ################################################################################################ -->
  </header>
</div>

<div class="wrapper bgded overlay" style="background-image:url('images/demo/backgrounds/voter-id-card.jpeg');">
  <div id="pageintro" class="hoc clear"> 
    <!-- ################################################################################################ -->
    <article>
      <div>
        <p class="heading">"Apply here for Your"</p>
        <h2 class="heading">New Voter ID </h2>
        <p>.</p>
      </div>	
    </article>
    <!-- ################################################################################################ -->
  </div>
</div>
<br>

<div class="wrapper bgded overlay" style="background-image:url('images/demo/backgrounds/Batman_Amoled-wallpaper-11337056.jpg');">
  
<form action="voter_check.php" method="Post">
 <div id="pageintro" class="hoc clear"> 
       <fieldset><br>
           <legend align="center" class="text-white"><h3>Applying For Voter Id</h3></legend>
            <legend align="center" class="text-white"><h6>Application for Inclusion of Name in Electoral Roll for First time Voter </h6></legend>
           <div class="form-group row">
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <div class="col-md-3">
                   <label for="firstName" class="text-white"><b>First Name *</b> </label>
                   <input type="text" class="form-control" name="firstName" 
                   id="firstName" placeholder="Please enter first name" pattern="[A-Za-z]+" title="only letters" required>
               </div>
               
               <div class="col-md-3">
                   <label for="firstName" class="text-white"><b>SurName *</b> </label>
                   <input type="text" class="form-control" name="lastname" 
                   id="firstName" placeholder="Please enter last name" pattern="[A-Za-z]+" title="only letters" required>
               </div>
           </div>

            <div class="form-group row">
            	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <div class="col-md-5">
                   <label for="firstName" class="text-white"><b>Name and surname of Relative of
Applicant *</b> </label>
                   <input type="text" class="form-control" name="nsrelative" 
                   id="firstName" placeholder="Please enter applicant name" pattern="[A-Za-z\s]+" title="only letters" required>
               </div>
               <div class="col-md-3">
                   <label for="firstName" class="text-white"><b>Type of Relation *</b> </label>
                  
		                     <select class="form-control" name="sonof" required>
                          <option value="S">Select</option>
              						<option value="F">Father</option>
              						<option value="M">Mother</option>
              						<option value="H">Husband</option>
              						<option value="W">Wife</option>
              						<option value="O">Other</option>
              					</select>
               </div>
              
            </div>	

           <div class="form-group row">
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <div class="col-md-4">
                   <label for="firstName" class="text-white"><b>Age *</b> </label>
                   <input type="number" name="age" class="form-control" id="number" min="18" max="100" placeholder="Please enter age" required>
               </div>
                <div class="form-group col-md-3">
			    <label for="bday" class="text-white"><b>Enter Birth Date *</b></label>
			    <input type="date" id="bday" name="bday" class="form-control" required="">
 			 </div>
 			  <div class="col-md-3">
                   <label for="firstName" class="text-white"><b>Gender *</b> </label>
                   <!--<input type="drop" class="form-control" name="lastname" 
                   id="firstName" placeholder="Please enter last name">-->
                     <select class="form-control" name="gender" pattern="[A-Za-z]+" title="only letters"><option value="S">Select</option>
					<option value="M">Male</option>
					<option value="F">Female</option>
					<option value="O">Other</option>
					</select>
               </div>
           </div> 
           <label class="text-white">
              <b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Current address where applicant is ordinarily resident *</b>
            </label><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
           
          	<div class="form-row">
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div class="col-md-3 mb-3">
                
                <label for="validationCustom03" class="text-white"><b>House No *</b></label>
                <input type="text" name="building" class="form-control" id="validationCustom03" placeholder="Enter House No" pattern="[A-Za-z][A-Za-z0-9-_|/.\s]{5.20}$" title="numbers only" required>
                <div class="invalid-feedback" class="text-white">
                  Please provide a valid address.
                </div>
              </div>
          </div>
          	
           <div class="form-row">
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div class="col-md-3 mb-3">
                
                <label for="validationCustom03" class="text-white"><b>Street/Area/Locality *</b></label>
                <input type="text" name="street" class="form-control" id="validationCustom03" placeholder="Name of Street/Area/Locality" pattern="[A-Za-z]+" title="only letters" required>
                <div class="invalid-feedback" class="text-white">
                  Please provide a valid address.
                </div>
              </div><br>
              <div class="col-md-3 mb-3">
                <label for="validationCustom04" class="text-white"><b>Town/Village * </b></label><br>
                <input type="text" name="town" class="form-control" id="validationCustom04" placeholder="Town/Village" pattern="[A-Za-z]+" title="only letters" required>
                <div class="invalid-feedback" class="text-white">
                  Please provide a town/village.
                </div>
              </div>
              <div class="col-md-3 mb-3">
                <label for="validationCustom05" class="text-white"><b>Post Office *</b></label>
                <input type="text" class="form-control" name="area" id="validationCustom05" placeholder="Post Office" pattern="[A-Za-z0-9]+" title="numbers and letters only" required>
                <div class="invalid-feedback" class="text-white">
                  Please provide a valid post office.
                </div>
              </div>
 		 </div>

           
           <div class="form-row">
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div class="col-md-3 mb-3">
                <label for="validationCustom03" class="text-white"><b>City *</b></label>
                <input type="text" name="city" class="form-control" id="validationCustom03" placeholder="City" pattern="[A-Za-z]+" title="only letters" required>
                <div class="invalid-feedback">
                  Please provide a valid city.
                </div>
              </div>
              <div class="col-md-3 mb-3">
                <label for="validationCustom04" class="text-white"><b>State * </b></label>
                <input type="text" name="state" class="form-control" id="validationCustom04" placeholder="State" pattern="[A-Za-z]+" title="only letters" required>
                <div class="invalid-feedback">
                  Please provide a valid state.
                </div>
              </div>
              <div class="col-md-3 mb-3">
                <label for="validationCustom05" class="text-white"><b>PinCode *</b></label>
                <input type="text" name="pincode" class="form-control" id="validationCustom05" placeholder="pincode" pattern="[0-9]+" title="numbers only" required>
                <div class="invalid-feedback">
                  Please provide a valid pincode.
                </div>
              </div>
 		 </div>
 		 <br>
 		  <label class="text-white">
              <b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Permanent address of applicant *</b>
            </label><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
           
          	<div class="form-row">
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div class="col-md-3 mb-3">
                
                <label for="validationCustom03" class="text-white"><b>House No *</b></label>
                <input type="text" name="building" class="form-control" id="validationCustom03" placeholder="Enter House No" pattern="[A-Za-z][A-Za-z0-9-_|/.\s]{5.20}$" title="numbers only"  required>
                <div class="invalid-feedback" class="text-white">
                  Please provide a valid address.
                </div>
              </div>
          </div>
          	
           <div class="form-row">
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div class="col-md-3 mb-3">
                
                <label for="validationCustom03" class="text-white"><b>Street/Area/Locality *</b></label>
                <input type="text" name="locality" class="form-control" id="validationCustom03" placeholder="Name of Street/Area/Locality" pattern="[A-Za-z]+" title="only letters" required>
                <div class="invalid-feedback" class="text-white">
                  Please provide a valid address.
                </div>
              </div><br>
              <div class="col-md-3 mb-3">
                <label for="validationCustom04" class="text-white"><b>Town/Village * </b></label><br>
                <input type="text" name="village" class="form-control" id="validationCustom04" placeholder="Town/Village" pattern="[A-Za-z]+" title="only letters" required>
                <div class="invalid-feedback" class="text-white">
                  Please provide a town/village.
                </div>
              </div>
              <div class="col-md-3 mb-3">
                <label for="validationCustom05" class="text-white"><b>Post Office</b></label>
                <input type="text" class="form-control" name="postoffice" id="validationCustom05" placeholder="Post Office" pattern="[A-Za-z0-9]+" title="numbers only" required>
                <div class="invalid-feedback" class="text-white">
                  Please provide a valid post office.
                </div>
              </div>
 		 </div>

           
           <div class="form-row">
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div class="col-md-3 mb-3">
                <label for="validationCustom03" class="text-white"><b>City *</b></label>
                <input type="text" name="city1" class="form-control" id="validationCustom03" placeholder="City" pattern="[A-Za-z]+" title="only letters" required>
                <div class="invalid-feedback">
                  Please provide a valid city.
                </div>
              </div>
              <div class="col-md-3 mb-3">
                <label for="validationCustom04" class="text-white"><b>State * </b></label>
                <input type="text" name="state2" class="form-control" id="validationCustom04" placeholder="State" pattern="[A-Za-z]+" title="only letters" required>
                <div class="invalid-feedback">
                  Please provide a valid state.
                </div>
              </div>
              <div class="col-md-3 mb-3">
                <label for="validationCustom05" class="text-white"><b>PinCode *</b></label>
                <input type="text" name="pincode2" class="form-control" id="validationCustom05" placeholder="pincode" pattern="[0-9]+" title="numbers only" required>
                <div class="invalid-feedback">
                  Please provide a valid pincode.
                </div>
              </div>
 		 </div>
 		 <br>
 		 <label class="text-white">
              <h6><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Optional Particulars *</b></h6>
            </label><br>

            <div class="form-row">
            	 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div class="col-md-3">
                   <label for="firstName" class="text-white"><b>&nbsp;&nbsp;Disability (if any) *</b> </label>
                   <!--<input type="drop" class="form-control" name="lastname" 
                   id="firstName" placeholder="Please enter last name">-->
                     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<select class="form-control" name="disability" required><option value="S">Select</option>
                     	<option value="n">none</option>
							<option value="v">Visual impairment</option>
							<option value="s">Speech & hearing disability</option>
							<option value="l">Locomotor disability</option>
							<option value="o">Other</option>

							</select>
               </div>
            </div>
            <br>
            <div class="form-row">
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div class="col-md-3 mb-3">
                
                <label for="validationCustom03" class="text-white"><b>Email Id *</b></label>
                <input type="text" name="email" class="form-control" id="validationCustom03" placeholder="Email-id" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" title="xyz@something.com" required>
                <div class="invalid-feedback" class="text-white">
                  Please provide a valid email.
                </div>
              </div><br>
              <div class="col-md-3 mb-3">
                <label for="validationCustom04" class="text-white"><b>Phone No * </b></label><br>
                <input type="text" name="phone" class="form-control" id="validationCustom04" placeholder="phone no" pattern="[0-9]+" title="numbers only" required>
                <div class="invalid-feedback" class="text-white">
                  Please provide a phone no.
                </div>
              </div>
              
 		 </div>
 		 <label class="text-white">
              <h6><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Please Upload Your Documents *</b></h6>
            </label><br>

             <div class="form-row">
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div class="col-md-3 mb-3">
                <label for="validationCustom03" class="text-white"><b>Upload Image *</b></label>
                  <input type="file" name="uploadimg" class="form-control-file" id="exampleInputFile" aria-describedb="fileHelp" required>
              </div>
              
              <div class="col-md-3 mb-3">
                <label for="validationCustom05" class="text-white"><b>Upload Adhar *</b></label>
                <input type="file" name="uploadadhar" class="form-control-file" id="exampleInputFile" aria-describedb="fileHelp" required>
                
              </div>
 		 </div>	
 		 <br>
 		 <br>
 		 <br>
 		  <div align="center" class="">
	 	 <input type = "Submit" Value = "Submit Application" width="150px" class="btn btn-success" />            
     </div>
	 </div>
	
	
   </fieldset>
</form>
</div>



<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!--<div class="wrapper row5">
  <div id="copyright" class="hoc clear"> 
     ################################################################################################ 
    <p class="fl_left">Copyright &copy; 2018 - All Rights Reserved - <a href="#">CIVIL REGISTRY</a></p>
    
    <!- -################################################################################################
  </div>
</div> -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!--<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>-->
<!-- JAVASCRIPTS -->
<script src="layout/scripts/jquery.min.js"></script>
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
</body>
</html>